﻿namespace eBanking
{
    partial class New_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LABEL_BALANCE = new System.Windows.Forms.Label();
            this.LABEL_WLC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TEXTBOX_RECEIVER_ID = new System.Windows.Forms.TextBox();
            this.TEXTBOX_AMOUNT = new System.Windows.Forms.TextBox();
            this.BUTTON_SIGNUP = new ePOSOne.btnProduct.Button_WOC();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // LABEL_BALANCE
            // 
            this.LABEL_BALANCE.AutoSize = true;
            this.LABEL_BALANCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LABEL_BALANCE.ForeColor = System.Drawing.Color.Teal;
            this.LABEL_BALANCE.Location = new System.Drawing.Point(353, 73);
            this.LABEL_BALANCE.Name = "LABEL_BALANCE";
            this.LABEL_BALANCE.Size = new System.Drawing.Size(74, 20);
            this.LABEL_BALANCE.TabIndex = 3;
            this.LABEL_BALANCE.Text = "Balance";
            // 
            // LABEL_WLC
            // 
            this.LABEL_WLC.AutoSize = true;
            this.LABEL_WLC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LABEL_WLC.ForeColor = System.Drawing.Color.Teal;
            this.LABEL_WLC.Location = new System.Drawing.Point(305, 36);
            this.LABEL_WLC.Name = "LABEL_WLC";
            this.LABEL_WLC.Size = new System.Drawing.Size(176, 24);
            this.LABEL_WLC.TabIndex = 5;
            this.LABEL_WLC.Text = "Available Balance";
            this.LABEL_WLC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(36, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "➋";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(35, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Receiver iBank:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(35, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Amount To Transfer:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(36, 285);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 18);
            this.label2.TabIndex = 12;
            this.label2.Text = "➋";
            // 
            // TEXTBOX_RECEIVER_ID
            // 
            this.TEXTBOX_RECEIVER_ID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.TEXTBOX_RECEIVER_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TEXTBOX_RECEIVER_ID.ForeColor = System.Drawing.Color.White;
            this.TEXTBOX_RECEIVER_ID.Location = new System.Drawing.Point(62, 183);
            this.TEXTBOX_RECEIVER_ID.Name = "TEXTBOX_RECEIVER_ID";
            this.TEXTBOX_RECEIVER_ID.Size = new System.Drawing.Size(146, 21);
            this.TEXTBOX_RECEIVER_ID.TabIndex = 14;
            // 
            // TEXTBOX_AMOUNT
            // 
            this.TEXTBOX_AMOUNT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.TEXTBOX_AMOUNT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TEXTBOX_AMOUNT.ForeColor = System.Drawing.Color.White;
            this.TEXTBOX_AMOUNT.Location = new System.Drawing.Point(62, 285);
            this.TEXTBOX_AMOUNT.Name = "TEXTBOX_AMOUNT";
            this.TEXTBOX_AMOUNT.Size = new System.Drawing.Size(146, 21);
            this.TEXTBOX_AMOUNT.TabIndex = 15;
            // 
            // BUTTON_SIGNUP
            // 
            this.BUTTON_SIGNUP.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_SIGNUP.BorderColor = System.Drawing.Color.Teal;
            this.BUTTON_SIGNUP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_SIGNUP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_SIGNUP.FlatAppearance.BorderSize = 0;
            this.BUTTON_SIGNUP.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_SIGNUP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_SIGNUP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_SIGNUP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_SIGNUP.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_SIGNUP.Location = new System.Drawing.Point(96, 330);
            this.BUTTON_SIGNUP.Name = "BUTTON_SIGNUP";
            this.BUTTON_SIGNUP.OnHoverBorderColor = System.Drawing.Color.Teal;
            this.BUTTON_SIGNUP.OnHoverButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_SIGNUP.OnHoverTextColor = System.Drawing.Color.Lime;
            this.BUTTON_SIGNUP.Size = new System.Drawing.Size(75, 25);
            this.BUTTON_SIGNUP.TabIndex = 21;
            this.BUTTON_SIGNUP.Text = "✓";
            this.BUTTON_SIGNUP.TextColor = System.Drawing.Color.Teal;
            this.BUTTON_SIGNUP.UseVisualStyleBackColor = true;
            this.BUTTON_SIGNUP.Click += new System.EventHandler(this.BUTTON_SIGNUP_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::eBanking.Properties.Resources.logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Location = new System.Drawing.Point(39, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 90);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // New_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(505, 383);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BUTTON_SIGNUP);
            this.Controls.Add(this.TEXTBOX_AMOUNT);
            this.Controls.Add(this.TEXTBOX_RECEIVER_ID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LABEL_WLC);
            this.Controls.Add(this.LABEL_BALANCE);
            this.Name = "New_Transaction";
            this.Text = "New Transaction";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LABEL_BALANCE;
        private System.Windows.Forms.Label LABEL_WLC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TEXTBOX_RECEIVER_ID;
        private System.Windows.Forms.TextBox TEXTBOX_AMOUNT;
        private ePOSOne.btnProduct.Button_WOC BUTTON_SIGNUP;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}