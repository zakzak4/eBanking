﻿namespace eBanking
{
    partial class eBanking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TEXTBOX_USERNAME = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LABEL_USERNAME = new System.Windows.Forms.Label();
            this.BUTTON_LOGIN = new ePOSOne.btnProduct.Button_WOC();
            this.TEXTBOX_PASSWORD = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BUTTON_SIGNUP = new ePOSOne.btnProduct.Button_WOC();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TEXTBOX_USERNAME);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.LABEL_USERNAME);
            this.groupBox1.Controls.Add(this.BUTTON_LOGIN);
            this.groupBox1.Controls.Add(this.TEXTBOX_PASSWORD);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Teal;
            this.groupBox1.Location = new System.Drawing.Point(61, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 290);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LOGIN";
            // 
            // TEXTBOX_USERNAME
            // 
            this.TEXTBOX_USERNAME.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.TEXTBOX_USERNAME.ForeColor = System.Drawing.Color.White;
            this.TEXTBOX_USERNAME.Location = new System.Drawing.Point(41, 91);
            this.TEXTBOX_USERNAME.Name = "TEXTBOX_USERNAME";
            this.TEXTBOX_USERNAME.Size = new System.Drawing.Size(123, 22);
            this.TEXTBOX_USERNAME.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Password:";
            // 
            // LABEL_USERNAME
            // 
            this.LABEL_USERNAME.AutoSize = true;
            this.LABEL_USERNAME.BackColor = System.Drawing.Color.Transparent;
            this.LABEL_USERNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LABEL_USERNAME.Location = new System.Drawing.Point(38, 54);
            this.LABEL_USERNAME.Name = "LABEL_USERNAME";
            this.LABEL_USERNAME.Size = new System.Drawing.Size(82, 16);
            this.LABEL_USERNAME.TabIndex = 3;
            this.LABEL_USERNAME.Text = "Username:";
            // 
            // BUTTON_LOGIN
            // 
            this.BUTTON_LOGIN.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_LOGIN.BorderColor = System.Drawing.Color.Teal;
            this.BUTTON_LOGIN.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_LOGIN.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_LOGIN.FlatAppearance.BorderSize = 0;
            this.BUTTON_LOGIN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_LOGIN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_LOGIN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_LOGIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_LOGIN.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_LOGIN.Location = new System.Drawing.Point(67, 241);
            this.BUTTON_LOGIN.Name = "BUTTON_LOGIN";
            this.BUTTON_LOGIN.OnHoverBorderColor = System.Drawing.Color.Teal;
            this.BUTTON_LOGIN.OnHoverButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_LOGIN.OnHoverTextColor = System.Drawing.Color.Lime;
            this.BUTTON_LOGIN.Size = new System.Drawing.Size(75, 25);
            this.BUTTON_LOGIN.TabIndex = 16;
            this.BUTTON_LOGIN.Text = "✓";
            this.BUTTON_LOGIN.TextColor = System.Drawing.Color.Teal;
            this.BUTTON_LOGIN.UseVisualStyleBackColor = true;
            this.BUTTON_LOGIN.Click += new System.EventHandler(this.BUTTON_LOGIN_Click);
            // 
            // TEXTBOX_PASSWORD
            // 
            this.TEXTBOX_PASSWORD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.TEXTBOX_PASSWORD.ForeColor = System.Drawing.Color.White;
            this.TEXTBOX_PASSWORD.Location = new System.Drawing.Point(41, 187);
            this.TEXTBOX_PASSWORD.Name = "TEXTBOX_PASSWORD";
            this.TEXTBOX_PASSWORD.Size = new System.Drawing.Size(123, 22);
            this.TEXTBOX_PASSWORD.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(120, 368);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "No Account?";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(97, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 25);
            this.label3.TabIndex = 19;
            this.label3.Text = "WELCOME!";
            // 
            // BUTTON_SIGNUP
            // 
            this.BUTTON_SIGNUP.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_SIGNUP.BorderColor = System.Drawing.Color.Teal;
            this.BUTTON_SIGNUP.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_SIGNUP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_SIGNUP.FlatAppearance.BorderSize = 0;
            this.BUTTON_SIGNUP.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_SIGNUP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_SIGNUP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_SIGNUP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_SIGNUP.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_SIGNUP.Location = new System.Drawing.Point(128, 399);
            this.BUTTON_SIGNUP.Name = "BUTTON_SIGNUP";
            this.BUTTON_SIGNUP.OnHoverBorderColor = System.Drawing.Color.Teal;
            this.BUTTON_SIGNUP.OnHoverButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_SIGNUP.OnHoverTextColor = System.Drawing.Color.Lime;
            this.BUTTON_SIGNUP.Size = new System.Drawing.Size(75, 25);
            this.BUTTON_SIGNUP.TabIndex = 18;
            this.BUTTON_SIGNUP.Text = "SIGN UP";
            this.BUTTON_SIGNUP.TextColor = System.Drawing.Color.Teal;
            this.BUTTON_SIGNUP.UseVisualStyleBackColor = true;
            this.BUTTON_SIGNUP.Click += new System.EventHandler(this.BUTTON_SIGNUP_Click);
            // 
            // eBanking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(335, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BUTTON_SIGNUP);
            this.Controls.Add(this.groupBox1);
            this.Name = "eBanking";
            this.Text = "Zak International Bank";
            this.Load += new System.EventHandler(this.eBanking_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TEXTBOX_PASSWORD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LABEL_USERNAME;
        private ePOSOne.btnProduct.Button_WOC BUTTON_LOGIN;
        private System.Windows.Forms.TextBox TEXTBOX_USERNAME;
        private ePOSOne.btnProduct.Button_WOC BUTTON_SIGNUP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}